package com.example.yangxu.mysearchapp;

/**
 * Created by yangxu on 6/6/17.
 */

import java.util.ArrayList;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class TweetAdapter extends BaseAdapter {
    private static final String TAG = "TweetAdapter";
    private SQLiteDatabase db;
    Context context;
    private Cursor cursor;

    public TweetAdapter(Context context, SQLiteDatabase tweetDb) {
        db = tweetDb;
        this.context = context;
        cursor = this.db.rawQuery("SELECT  * FROM " + TweetContract.TABLE_NAME, null);
    }

    @Override
    public int getCount() {
        return cursor.getCount();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Log.d(TAG, "TweetAdapter: getView");
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.tweet_list_item, null);
        }

        cursor = db.rawQuery("SELECT  * FROM " + TweetContract.TABLE_NAME, null);
        String tweetAuthor = "", tweetContent = "";
        if (cursor.moveToPosition(position)) {
            tweetContent = cursor.getString(2);
            tweetAuthor = cursor.getString(1);
        }

        TextView txtTweet = (TextView) convertView.findViewById(R.id.txtTweet);
        TextView txtTweetBy = (TextView) convertView.findViewById(R.id.txtTweetBy);
        txtTweet.setText(tweetContent);
        txtTweetBy.setText(tweetAuthor);
        cursor.close();
        return convertView;
    }
}