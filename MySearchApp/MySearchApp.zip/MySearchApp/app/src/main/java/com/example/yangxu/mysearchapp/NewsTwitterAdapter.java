package com.example.yangxu.mysearchapp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

/**
 * Created by yangxu on 6/20/17.
 */

public class NewsTwitterAdapter extends BaseAdapter {
    private static final String TAG = "NewsTwitterAdapter";
    private SQLiteDatabase db;
    Context context;
    private Cursor cursor;

    public NewsTwitterAdapter(Context context, SQLiteDatabase db) {
        this.db = db;
        this.context = context;
        cursor = this.db.rawQuery("SELECT  * FROM " + NewsTweetContract.TABLE_NAME, null);
    }

    @Override
    public int getCount() {
        return cursor.getCount();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Log.d(TAG, "NewsTwitterAdapter: getView");
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.tweet_list_item, null);
        }

        cursor = db.rawQuery("SELECT  * FROM " + NewsTweetContract.TABLE_NAME, null);
        String author = "", content = "", title = "";
        if (cursor.moveToPosition(position)) {
            content = cursor.getString(1);
            author = cursor.getString(2);
            title = cursor.getString(3);
        }

        TextView txtContent = (TextView) convertView.findViewById(R.id.txtTweet);
        TextView txtAuthor = (TextView) convertView.findViewById(R.id.txtTweetBy);
        TextView txtTitle = (TextView) convertView.findViewById(R.id.title);
        txtContent.setText(content);
        txtAuthor.setText(author);
        if (!txtTitle.equals(""))
            txtTitle.setText(title);
        cursor.close();
        return convertView;
    }
}
