package com.example.yangxu.mysearchapp;

import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.view.Menu;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterFactory;
import twitter4j.auth.OAuth2Token;
import twitter4j.conf.ConfigurationBuilder;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private final String TWIT_CONS_KEY = "2nMnP3ACl9wLN9CNY3XjZUVFq";
    private final String TWIT_CONS_SEC_KEY = "X6CV1OZGeXJjwVWeONTvJK1yfoj3Uvn8D8kQcdQhXew7FhJvCS";

    String url1 = "https://newsapi.org/v1/articles?source=bbc-news&sortBy=top&apiKey=26125c1be8304fa99e66084e63422fe1";
    String url2 = "https://newsapi.org/v1/articles?source=abc-news-au&sortBy=top&apiKey=26125c1be8304fa99e66084e63422fe1";
    String url3 = "https://newsapi.org/v1/articles?source=cnn&sortBy=top&apiKey=26125c1be8304fa99e66084e63422fe1";
    String url4 = "https://newsapi.org/v1/articles?source=the-washington-post&sortBy=top&apiKey=26125c1be8304fa99e66084e63422fe1";
    String url5 = "https://newsapi.org/v1/articles?source=usa-today&sortBy=top&apiKey=26125c1be8304fa99e66084e63422fe1";
    String url6 = "https://newsapi.org/v1/articles?source=the-new-york-times&sortBy=top&apiKey=26125c1be8304fa99e66084e63422fe1";
    String url7 = "https://newsapi.org/v1/articles?source=cnbc&sortBy=top&apiKey=26125c1be8304fa99e66084e63422fe1";
    String url8 = "https://newsapi.org/v1/articles?source=time&sortBy=top&apiKey=26125c1be8304fa99e66084e63422fe1";
    String url9 = "https://newsapi.org/v1/articles?source=newsweek&sortBy=top&apiKey=26125c1be8304fa99e66084e63422fe1";
    String url10 = "https://newsapi.org/v1/articles?source=independent&sortBy=top&apiKey=26125c1be8304fa99e66084e63422fe1";

    ArrayList<String> urlList = new ArrayList<>();
    ArrayList<List<Status>> newsTimeline;
    boolean foundTweets = false;
    boolean foundSource = false;
    SQLiteDatabase db;
    EditText edtSearch;
    Button btnSearch;
    ListView list;
    ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edtSearch = (EditText) findViewById(R.id.edtSearch);
        btnSearch = (Button) findViewById(R.id.btnSearch);
        list = (ListView) findViewById(R.id.list);
        urlList.add(url1);
        urlList.add(url2);
        urlList.add(url3);
        urlList.add(url4);
        urlList.add(url5);
        urlList.add(url6);
        urlList.add(url7);
        urlList.add(url8);
        urlList.add(url9);
        urlList.add(url10);
        btnSearch.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                new GetNewsAndTweets().execute(edtSearch.getText().toString());
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_selection, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.news:
                Intent intentNews = new Intent(this, SearchOnNews.class);
                this.startActivity(intentNews);
                break;
            case R.id.twitter:
                Intent intentTweet = new Intent(this, SearchOnTwitter.class);
                this.startActivity(intentTweet);
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }

    protected class GetNewsAndTweets extends AsyncTask<String, Void, Boolean> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = new ProgressDialog(MainActivity.this);
            dialog.setMessage("Please wait...");
            dialog.show();
        }

        @Override
        protected Boolean doInBackground(String... params) {
            Log.d(TAG, "SearchOnNewsAndTwitter: doInBackground starts.");
            try {
                ConfigurationBuilder builder = new ConfigurationBuilder();
                builder.setApplicationOnlyAuthEnabled(true);
                builder.setOAuthConsumerKey(TWIT_CONS_KEY);
                builder.setOAuthConsumerSecret(TWIT_CONS_SEC_KEY);

                OAuth2Token token = new TwitterFactory(builder.build()).getInstance().getOAuth2Token();

                builder = new ConfigurationBuilder();
                builder.setApplicationOnlyAuthEnabled(true);
                builder.setOAuthConsumerKey(TWIT_CONS_KEY);
                builder.setOAuthConsumerSecret(TWIT_CONS_SEC_KEY);
                builder.setOAuth2TokenType(token.getTokenType());
                builder.setOAuth2AccessToken(token.getAccessToken());
                Twitter twitter = new TwitterFactory(builder.build()).getInstance();

                List<twitter4j.Status> abcTimeLine = twitter.getUserTimeline("abc");
                List<twitter4j.Status> cnnTimeLine = twitter.getUserTimeline("cnn");
                List<twitter4j.Status> bbcTimeLine = twitter.getUserTimeline("bbc");
                List<twitter4j.Status> wpTimeLine = twitter.getUserTimeline("washingtonpost");
                List<twitter4j.Status> usatodayTimeLine = twitter.getUserTimeline("USATODAY");
                List<twitter4j.Status> nytimesTimeLine = twitter.getUserTimeline("nytimes");
                List<twitter4j.Status> cnbcTimeLine = twitter.getUserTimeline("cnbc");
                List<twitter4j.Status> tTimeLine = twitter.getUserTimeline("TIME");
                List<twitter4j.Status> nwTimeLine = twitter.getUserTimeline("TIME");
                List<twitter4j.Status> idTimeLine = twitter.getUserTimeline("independent");
                newsTimeline = new ArrayList<>();
                newsTimeline.add(abcTimeLine);
                newsTimeline.add(cnnTimeLine);
                newsTimeline.add(bbcTimeLine);
                newsTimeline.add(wpTimeLine);
                newsTimeline.add(usatodayTimeLine);
                newsTimeline.add(nytimesTimeLine);
                newsTimeline.add(cnbcTimeLine);
                newsTimeline.add(tTimeLine);
                newsTimeline.add(nwTimeLine);
                newsTimeline.add(idTimeLine);

                DatabaseHelper helper = DatabaseHelper.getInstance(MainActivity.this);
                db = helper.getWritableDatabase();
                db.delete(NewsTweetContract.TABLE_NAME, null, null);

                for (List<twitter4j.Status> aTimeLine : newsTimeline) {
                    for (twitter4j.Status tweet : aTimeLine) {
                        if (tweet.getText().toLowerCase().contains(params[0].toLowerCase())) {
                            ContentValues values = new ContentValues();
                            values.put(NewsTweetContract.Columns.COLUMN_NAME_CONTENT, tweet.getText());
                            values.put(NewsTweetContract.Columns.COLUMN_NAME_AUTHOR, "@" + tweet.getUser().getScreenName());
                            db.insert(NewsTweetContract.TABLE_NAME, null, values);
                            foundTweets = true;
                        }
                    }
                }
                Log.d(TAG, "SearchOnNewsAndTwitter: doInBackground complete.");
            } catch (Exception e) {
                Log.d(TAG, "SearchOnNewsAndTwitter: InCatchExceptions.");
                e.printStackTrace();
            }

            for (String link : urlList) {
                HttpHandler sh = new HttpHandler();
                String jsonStr = sh.makeServiceCall(link);
                Log.e(TAG, "Response from url");

                if (jsonStr != null) {
                    try {
                        JSONObject jsonObject = new JSONObject(jsonStr);
                        JSONArray articles = jsonObject.getJSONArray("articles");
                        String source = jsonObject.getString("source");

                        for (int i = 0; i < articles.length(); i++) {
                            JSONObject c = articles.getJSONObject(i);
                            String title = c.getString("title");
                            String description = c.getString("description");

                            if (title.toLowerCase().contains(params[0].toLowerCase())
                                    || description.toLowerCase().contains(params[0].toLowerCase())) {
                                ContentValues values = new ContentValues();
                                values.put(NewsTweetContract.Columns.COLUMN_NAME_TITLE, title);
                                values.put(NewsTweetContract.Columns.COLUMN_NAME_CONTENT, description);
                                values.put(NewsTweetContract.Columns.COLUMN_NAME_AUTHOR, source);
                                db.insert(NewsTweetContract.TABLE_NAME, null, values);

                                foundSource = true;
                            }
                        }
                    } catch (final JSONException e) {
                        Log.e(TAG, "JSON parsing error: " + e.getMessage());
                        Toast.makeText(MainActivity.this, "Json Parsing error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Log.e(TAG, "Could not get JSON from server.");
                    Toast.makeText(MainActivity.this, "Could not get JSON from server", Toast.LENGTH_SHORT).show();
                }
            }
            return foundTweets || foundSource;
        }

        @Override
        protected void onPostExecute(Boolean result) {
            Log.d(TAG, "SearchNewsAndTwitter: onPostExecute.");
            super.onPostExecute(result);
            dialog.dismiss();
            if (foundTweets || foundSource) {
                list.setAdapter(new NewsTwitterAdapter(MainActivity.this, db));
            } else {
                Toast.makeText(MainActivity.this, "Could not find relevant info in both news and tweets.", Toast.LENGTH_LONG).show();
            }
        }
    }
}



