package com.example.yangxu.mysearchapp;

import android.provider.BaseColumns;

/**
 * Created by yangxu on 6/20/17.
 */

public final class TweetContract {
    static final String TABLE_NAME = "TweetEntry";

    public static class Columns {
        public static final String _ID = BaseColumns._ID;
        public static final String COLUMN_NAME_TWEET_CONTENT = "TweetContent";
        public static final String COLUMN_NAME_TWEET_AUTHOR = "TweetAuthor";

        private Columns() {
            // private constructor to prevent instantiation
        }
    }
}
