package com.example.yangxu.mysearchapp;

import android.provider.BaseColumns;

/**
 * Created by yangxu on 6/20/17.
 */

public final class NewsContract {
    static final String TABLE_NAME = "NewsEntry";

    public static class Columns {
        public static final String _ID = BaseColumns._ID;
        public static final String COLUMN_NAME_NEWS_TITLE = "NewsTitle";
        public static final String COLUMN_NAME_NEWS_DESCRIPTION = "NewsDescription";
        public static final String COLUMN_NAME_NEWS_SOURCE = "NewsSource";

        private Columns() {
            // private constructor to prevent instantiation
        }
    }
}
