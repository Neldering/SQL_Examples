package com.example.yangxu.mysearchapp;

import android.app.ProgressDialog;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import twitter4j.Twitter;
import twitter4j.TwitterFactory;
import twitter4j.auth.OAuth2Token;
import twitter4j.conf.ConfigurationBuilder;

/**
 * Created by yangxu on 6/13/17.
 */

public class SearchOnTwitter extends AppCompatActivity {
    private static final String TAG = "SearchOnTwitter";
    EditText edtSearch;
    Button btnSearch;
    ListView list;
    private final String TWIT_CONS_KEY = "2nMnP3ACl9wLN9CNY3XjZUVFq";
    private final String TWIT_CONS_SEC_KEY = "X6CV1OZGeXJjwVWeONTvJK1yfoj3Uvn8D8kQcdQhXew7FhJvCS";

    SQLiteDatabase tweetdb;
    ArrayList<List<twitter4j.Status>> newsTimeline;
    boolean foundTweets = false;
    ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "SearchOnTwitter: onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edtSearch = (EditText) findViewById(R.id.edtSearch);
        btnSearch = (Button) findViewById(R.id.btnSearch);
        list = (ListView) findViewById(R.id.list);
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new GetTweets().execute(edtSearch.getText().toString());
            }
        });
    }

    protected class GetTweets extends AsyncTask<String, Void, Boolean> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = new ProgressDialog(SearchOnTwitter.this);
            dialog.setMessage("Please wait...");
            dialog.show();
        }

        @Override
        protected Boolean doInBackground(String... params) {
            Log.d(TAG, "SearchOnTwitter: doInBackground starts.");
            try {
                ConfigurationBuilder builder = new ConfigurationBuilder();
                builder.setApplicationOnlyAuthEnabled(true);
                builder.setOAuthConsumerKey(TWIT_CONS_KEY);
                builder.setOAuthConsumerSecret(TWIT_CONS_SEC_KEY);

                OAuth2Token token = new TwitterFactory(builder.build()).getInstance().getOAuth2Token();

                builder = new ConfigurationBuilder();
                builder.setApplicationOnlyAuthEnabled(true);
                builder.setOAuthConsumerKey(TWIT_CONS_KEY);
                builder.setOAuthConsumerSecret(TWIT_CONS_SEC_KEY);
                builder.setOAuth2TokenType(token.getTokenType());
                builder.setOAuth2AccessToken(token.getAccessToken());
                Twitter twitter = new TwitterFactory(builder.build()).getInstance();

                List<twitter4j.Status> abcTimeLine = twitter.getUserTimeline("abc");
                List<twitter4j.Status> cnnTimeLine = twitter.getUserTimeline("cnn");
                List<twitter4j.Status> bbcTimeLine = twitter.getUserTimeline("bbc");
                List<twitter4j.Status> wpTimeLine = twitter.getUserTimeline("washingtonpost");
                List<twitter4j.Status> usatodayTimeLine = twitter.getUserTimeline("USATODAY");
                List<twitter4j.Status> nytimesTimeLine = twitter.getUserTimeline("nytimes");
                List<twitter4j.Status> cnbcTimeLine = twitter.getUserTimeline("cnbc");
                List<twitter4j.Status> tTimeLine = twitter.getUserTimeline("TIME");
                List<twitter4j.Status> nwTimeLine = twitter.getUserTimeline("TIME");
                List<twitter4j.Status> idTimeLine = twitter.getUserTimeline("independent");
                newsTimeline = new ArrayList<>();
                newsTimeline.add(abcTimeLine);
                newsTimeline.add(cnnTimeLine);
                newsTimeline.add(bbcTimeLine);
                newsTimeline.add(wpTimeLine);
                newsTimeline.add(usatodayTimeLine);
                newsTimeline.add(nytimesTimeLine);
                newsTimeline.add(cnbcTimeLine);
                newsTimeline.add(tTimeLine);
                newsTimeline.add(nwTimeLine);
                newsTimeline.add(idTimeLine);

                DatabaseHelper helper = DatabaseHelper.getInstance(SearchOnTwitter.this);
                tweetdb = helper.getWritableDatabase();
                tweetdb.delete(TweetContract.TABLE_NAME, null, null);

                for (List<twitter4j.Status> aTimeLine : newsTimeline) {
                    for (twitter4j.Status tweet : aTimeLine) {
                        if (tweet.getText().toLowerCase().contains(params[0].toLowerCase())) {
                            ContentValues values = new ContentValues();
                            values.put(TweetContract.Columns.COLUMN_NAME_TWEET_CONTENT, tweet.getText());
                            values.put(TweetContract.Columns.COLUMN_NAME_TWEET_AUTHOR, "@" + tweet.getUser().getScreenName());
                            tweetdb.insert(TweetContract.TABLE_NAME, null, values);
                            foundTweets = true;
                        }
                    }
                }
                Log.d(TAG, "SearchOnTwitter: doInBackground complete.");
            } catch (Exception e) {
                Log.d(TAG, "SearchOnTwitter: InCatchExceptions.");
                e.printStackTrace();
            }
            return foundTweets;
        }

        @Override
        protected void onPostExecute(Boolean result) {
            Log.d(TAG, "SearchOnTwitter: onPostExecute.");
            super.onPostExecute(result);
            dialog.dismiss();
            if (foundTweets) {
                list.setAdapter(new TweetAdapter(SearchOnTwitter.this, tweetdb));
            } else {
                Toast.makeText(SearchOnTwitter.this, "Could not find relevant tweets.", Toast.LENGTH_LONG).show();
            }
        }
    }
}
