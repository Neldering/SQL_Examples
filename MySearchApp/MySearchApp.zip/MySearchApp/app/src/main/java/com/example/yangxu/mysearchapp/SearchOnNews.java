package com.example.yangxu.mysearchapp;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by yangxu on 6/13/17.
 */

public class SearchOnNews extends AppCompatActivity {
    private static final String TAG = "SearchOnNews";
    String url1 = "https://newsapi.org/v1/articles?source=bbc-news&sortBy=top&apiKey=26125c1be8304fa99e66084e63422fe1";
    String url2 = "https://newsapi.org/v1/articles?source=abc-news-au&sortBy=top&apiKey=26125c1be8304fa99e66084e63422fe1";
    String url3 = "https://newsapi.org/v1/articles?source=cnn&sortBy=top&apiKey=26125c1be8304fa99e66084e63422fe1";
    String url4 = "https://newsapi.org/v1/articles?source=the-washington-post&sortBy=top&apiKey=26125c1be8304fa99e66084e63422fe1";
    String url5 = "https://newsapi.org/v1/articles?source=usa-today&sortBy=top&apiKey=26125c1be8304fa99e66084e63422fe1";
    String url6 = "https://newsapi.org/v1/articles?source=the-new-york-times&sortBy=top&apiKey=26125c1be8304fa99e66084e63422fe1";
    String url7 = "https://newsapi.org/v1/articles?source=cnbc&sortBy=top&apiKey=26125c1be8304fa99e66084e63422fe1";
    String url8 = "https://newsapi.org/v1/articles?source=time&sortBy=top&apiKey=26125c1be8304fa99e66084e63422fe1";
    String url9 = "https://newsapi.org/v1/articles?source=newsweek&sortBy=top&apiKey=26125c1be8304fa99e66084e63422fe1";
    String url10 = "https://newsapi.org/v1/articles?source=independent&sortBy=top&apiKey=26125c1be8304fa99e66084e63422fe1";

    private ArrayList<String> urlList = new ArrayList<>();
    SQLiteDatabase newsdb;
    boolean foundSource = false;
    EditText edtSearch;
    Button btnSearch;
    ListView list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        urlList.add(url1);
        urlList.add(url2);
        urlList.add(url3);
        urlList.add(url4);
        urlList.add(url5);
        urlList.add(url6);
        urlList.add(url7);
        urlList.add(url8);
        urlList.add(url9);
        urlList.add(url10);
        edtSearch = (EditText) findViewById(R.id.edtSearch);
        btnSearch = (Button) findViewById(R.id.btnSearch);
        list = (ListView) findViewById(R.id.list);
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 new GetNewsSources().execute(edtSearch.getText().toString());
            }
        });
    }

    protected class GetNewsSources extends AsyncTask<String, Void, Boolean> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Boolean doInBackground(String... params) {

            DatabaseHelper helper = DatabaseHelper.getInstance(SearchOnNews.this);
            newsdb = helper.getWritableDatabase();
            newsdb.delete(NewsContract.TABLE_NAME, null, null);

            for (String link : urlList) {
                HttpHandler sh = new HttpHandler();
                String jsonStr = sh.makeServiceCall(link);
                Log.e(TAG, "Response from url");

                if (jsonStr != null) {
                    try {
                        JSONObject jsonObject = new JSONObject(jsonStr);
                        JSONArray articles = jsonObject.getJSONArray("articles");
                        String source = jsonObject.getString("source");

                        for (int i = 0; i < articles.length(); i++) {
                            JSONObject c = articles.getJSONObject(i);
                            String title = c.getString("title");
                            String description = c.getString("description");

                            if (title.toLowerCase().contains(params[0].toLowerCase())
                                    || description.toLowerCase().contains(params[0].toLowerCase())) {

                                ContentValues values = new ContentValues();
                                values.put(NewsContract.Columns.COLUMN_NAME_NEWS_TITLE, title);
                                values.put(NewsContract.Columns.COLUMN_NAME_NEWS_DESCRIPTION, description);
                                values.put(NewsContract.Columns.COLUMN_NAME_NEWS_SOURCE, source);
                                newsdb.insert(NewsContract.TABLE_NAME, null, values);

                                foundSource = true;
                            }
                        }
                    } catch (final JSONException e) {
                        Log.e(TAG, "JSON parsing error: " + e.getMessage());
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(SearchOnNews.this, "Json Parsing error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                } else {
                    Log.e(TAG, "Could not get JSON from server.");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(SearchOnNews.this, "Could not get JSON from server", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
            return foundSource;
        }

        @Override
        protected void onPostExecute(Boolean result) {
            Log.d(TAG, "SearchOnNews: onPostExecute.");
            super.onPostExecute(result);
            if (foundSource) {
                list.setAdapter(new NewsAdapter(SearchOnNews.this, newsdb));
            } else {
                Toast.makeText(SearchOnNews.this, "Could not find relevant news.", Toast.LENGTH_LONG).show();
            }
        }
    }
}