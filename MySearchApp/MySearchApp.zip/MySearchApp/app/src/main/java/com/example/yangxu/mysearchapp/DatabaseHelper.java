package com.example.yangxu.mysearchapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String TAG = "DatabaseHelper";

    public static final String DATABASE_NAME = "SearchData.db";
    public static final int DATABASE_VERSION = 1;

    private static DatabaseHelper instance = null;

    private DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        Log.d(TAG, "Database: constructor");
    }

    static DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            Log.d(TAG, "getInstance: creating new instance");
            instance = new DatabaseHelper(context);
        }
        return instance;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d(TAG, "DatabaseHelper: onCreate");
        String tweetsSQL;
        tweetsSQL = "CREATE TABLE " + TweetContract.TABLE_NAME + " ("
                + TweetContract.Columns._ID + " INTEGER PRIMARY KEY NOT NULL, "
                + TweetContract.Columns.COLUMN_NAME_TWEET_AUTHOR + " TEXT NOT NULL, "
                + TweetContract.Columns.COLUMN_NAME_TWEET_CONTENT + " TEXT NOT NULL);";
        Log.d(TAG, "tweetsSQL");
        db.execSQL(tweetsSQL);

        String newssSQL;
        newssSQL = "CREATE TABLE " + NewsContract.TABLE_NAME + " ("
                + NewsContract.Columns._ID + " INTEGER PRIMARY KEY NOT NULL, "
                + NewsContract.Columns.COLUMN_NAME_NEWS_TITLE + " TEXT NOT NULL, "
                + NewsContract.Columns.COLUMN_NAME_NEWS_DESCRIPTION + " TEXT NOT NULL, "
                + NewsContract.Columns.COLUMN_NAME_NEWS_SOURCE + " TEXT NOT NULL);";
        Log.d(TAG, "newssSQL");
        db.execSQL(newssSQL);
        Log.d(TAG, "onCreate: ends");

        String newsTweetsSQL;
        newsTweetsSQL = "CREATE TABLE " + NewsTweetContract.TABLE_NAME + " ("
                + NewsTweetContract.Columns._ID + " INTEGER PRIMARY KEY NOT NULL, "
                + NewsTweetContract.Columns.COLUMN_NAME_CONTENT + " TEXT, "
                + NewsTweetContract.Columns.COLUMN_NAME_AUTHOR + " TEXT, "
                + NewsTweetContract.Columns.COLUMN_NAME_TITLE + " TEXT);";
        Log.d(TAG, "newstweetsSQL");
        db.execSQL(newsTweetsSQL);
        Log.d(TAG, "onCreate: ends");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.d(TAG, "onUpgrade: starts");
        switch (oldVersion) {
            case 1:
                // upgrade logic from version 1
                break;
            default:
                throw new IllegalStateException("onUpgrade() with unknown newVersion: " + newVersion);
        }
        Log.d(TAG, "onUpgrade: ends");
    }
}














