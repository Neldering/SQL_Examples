package com.example.yangxu.mysearchapp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

/**
 * Created by yangxu on 6/20/17.
 */

public class NewsAdapter extends BaseAdapter {
    private static final String TAG = "NewsAdapter";
    private SQLiteDatabase db;
    Context context;
    private Cursor cursor;

    public NewsAdapter(Context context, SQLiteDatabase Newsdb) {
        db = Newsdb;
        this.context = context;
        cursor = this.db.rawQuery("SELECT  * FROM " + NewsContract.TABLE_NAME, null);
    }

    @Override
    public int getCount() {
        return cursor.getCount();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Log.d(TAG, "NewsAdapter: getView");
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.tweet_list_item, null);
        }

        cursor = db.rawQuery("SELECT  * FROM " + NewsContract.TABLE_NAME, null);
        String newsTitle = "", newsDescription = "", source = "";
        if (cursor.moveToPosition(position)) {
            newsTitle = cursor.getString(1);
            newsDescription = cursor.getString(2);
            source = cursor.getString(3);
        }

        TextView txtTitle = (TextView) convertView.findViewById(R.id.title);
        TextView txtDescription = (TextView) convertView.findViewById(R.id.txtTweet);
        TextView txtSource = (TextView) convertView.findViewById(R.id.txtTweetBy);
        txtTitle.setText(newsTitle);
        txtDescription.setText(newsDescription);
        txtSource.setText(source);
        cursor.close();
        return convertView;
    }
}
