package com.example.yangxu.mysearchapp;

import android.provider.BaseColumns;

/**
 * Created by yangxu on 6/20/17.
 */

public class NewsTweetContract {
    static final String TABLE_NAME = "NewsTweetEntry";

    public static class Columns {
        public static final String _ID = BaseColumns._ID;
        public static final String COLUMN_NAME_CONTENT = "NewsDescription";
        public static final String COLUMN_NAME_AUTHOR = "NewsSource";
        public static final String COLUMN_NAME_TITLE = "NewsTitle";

        private Columns() {
            // private constructor to prevent instantiation
        }
    }
}